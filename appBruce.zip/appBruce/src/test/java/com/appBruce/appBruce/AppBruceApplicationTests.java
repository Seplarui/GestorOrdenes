package com.appBruce.appBruce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppBruceApplicationTests {

	@Test
	void contextLoads() {
	}

}
