package com.appBruce.appBruce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppBruceApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppBruceApplication.class, args);
	}

}
